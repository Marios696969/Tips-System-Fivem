
fx_version 'cerulean'
game 'gta5'

ui_page 'index.html'

files {
  'index.html'
}

client_script 'client.lua'
