

RegisterNetEvent('nui_greek_info:showUI')
AddEventHandler('nui_greek_info:showUI', function()
    SendNUIMessage({ type = "show" })
    SetNuiFocus(false, false)
end)


Citizen.CreateThread(function()
    Wait(3000)
    TriggerEvent('nui_greek_info:showUI')
end)
